package com.example.thermalmonitor.overview

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.thermalmonitor.R
import com.example.thermalmonitor.battery.BatteryViewModel
import com.example.thermalmonitor.soc.SocViewModel
import com.example.thermalmonitor.thermal.ThermalViewModel
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.timer
import kotlinx.android.synthetic.main.fragment_overview.*

class OverViewFragment : Fragment(R.layout.fragment_overview) {

    // 定义三个view model对象，用于获取电池、温度和Soc的数据
    private lateinit var batteryViewModel: BatteryViewModel
    private lateinit var thermalViewModel: ThermalViewModel
    private lateinit var socViewModel: SocViewModel

    // 定义一个计时器对象，用于记录时间
    private var timerTask: Timer? = null

    // 定义一个变量，用于记录是否在记录状态
    private var isRecording = false

    // 定义一个变量，用于记录开始时间
    private var startTime = 0L

    // 定义一个变量，用于记录结束时间
    private var endTime = 0L

    // 定义一个变量，用于记录已经记录的秒数
    private var seconds = 0

    // 定义三个二维数组，用于保存电池、温度和Soc的数据
    private val batteryDataArray = mutableListOf<MutableList<String>>()
    private val thermalDataArray = mutableListOf<MutableList<String>>()
    private val socDataArray = mutableListOf<MutableList<String>>()

    @Deprecated("Deprecated in Java")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // 初始化view model对象
        batteryViewModel = ViewModelProvider(this).get(BatteryViewModel::class.java)
        thermalViewModel = ViewModelProvider(this).get(ThermalViewModel::class.java)
        socViewModel = ViewModelProvider(this).get(SocViewModel::class.java)

        // 设置按钮的点击事件监听器
        btn_start.setOnClickListener {
            startRecord()
        }

        btn_pause.setOnClickListener {
            pauseRecord()
        }

        btn_stop_save.setOnClickListener {
            stopAndSaveRecord()
        }
    }

    // 开始记录的方法
    private fun startRecord() {
        // 如果不在记录状态
        if (!isRecording) {
            // 设置记录状态为true
            isRecording = true

            // 获取当前时间作为开始时间
            startTime = System.currentTimeMillis()

            // 启动计时器，每隔一秒更新一次时间显示，并获取数据
            timerTask = timer(period = 1000) {
                // 更新秒数
                seconds++

                // 在主线程中更新UI
                activity?.runOnUiThread {
                    // 格式化时间显示
                    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    val timeString = timeFormat.format(seconds * 1000)
                    tv_time.text = timeString
                }

                // 获取数据
                getData()
            }
        } else {
            // 如果在记录状态，提示用户正在记录
            Toast.makeText(context, "正在记录中，请勿重复点击", Toast.LENGTH_SHORT).show()
        }
    }

    // 中止记录的方法
    private fun pauseRecord() {
        // 如果在记录状态
        if (isRecording) {
            // 弹出对话框，让用户二次确认是否中止
            AlertDialog.Builder(context).apply {
                setTitle("提示")
                setMessage("确定要中止记录吗？已经记录的数据将不会被保存。")
                setPositiveButton("确定") { _, _ ->
                    // 确定中止，停止计时器，设置记录状态为false，清空数据数组，重置时间显示和秒数
                    timerTask?.cancel()
                    isRecording = false
                    batteryDataArray.clear()
                    thermalDataArray.clear()
                    socDataArray.clear()
                    tv_time.text = "00:00:00"
                    seconds = 0
                }
                setNegativeButton("取消", null)
                show()
            }
        } else {
            // 如果不在记录状态，提示用户未开始记录
            Toast.makeText(context, "未开始记录，请先点击开始按钮", Toast.LENGTH_SHORT).show()
        }
    }

    // 停止并保存记录的方法
    private fun stopAndSaveRecord() {
        // 如果在记录状态
        if (isRecording) {
            // 停止计时器，设置记录状态为false，获取当前时间作为结束时间
            timerTask?.cancel()
            isRecording = false
            endTime = System.currentTimeMillis()

            // 保存数据到Excel文件，并提示用户是否保存成功以及保存路径
            saveDataToExcel()
        } else {
            // 如果不在记录状态，提示用户未开始记录
            Toast.makeText(context, "未开始记录，请先点击开始按钮", Toast.LENGTH_SHORT).show()
        }
    }

    // 获取数据的方法
    private fun getData() {
        // 定义一个变量，用于存储当前时间戳，作为每一行数据的第一列
        val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        // 如果勾选了电池选项，获取电池数据，并添加到电池数据数组中
        if (cb_battery.isChecked) {
            batteryViewModel.batteryData.observe(this, Observer { batteryData ->
                val batteryDataRow = mutableListOf<String>()
                batteryDataRow.add(timeStamp)
                batteryDataRow.add(batteryData.level.toString())
                batteryDataRow.add(batteryData.status)
                batteryDataRow.add(batteryData.current.toString())
                batteryDataRow.add(batteryData.temperature.toString())
                batteryDataRow.add(batteryData.voltage.toString())
                batteryDataRow.add(batteryData.source)
                batteryDataArray.add(batteryDataRow)
            })
        }

        // 如果勾选了温度选项，获取温度数据，并添加到温度数据数组中
        if (cb_temperature.isChecked) {
            thermalViewModel.thermalList.observe(this, Observer { thermalList ->
                val thermalDataRow = mutableListOf<String>()
                thermalDataRow.add(timeStamp)
                for (thermalData in thermalList) {
                    thermalDataRow.add(thermalData.temp)
                }
                thermalDataArray.add(thermalDataRow)
            })
        }

        // 如果勾选了Soc选项，获取Soc数据，并添加到Soc数据数组中
        if (cb_soc.isChecked) {
            socViewModel.dynamicInfo.observe(this, Observer { dynamicInfoList ->
                val socDataRow = mutableListOf<String>()
                socDataRow.add(timeStamp)
                for (dynamicInfo in dynamicInfoList) {
                    socDataRow.add(dynamicInfo.coreFrequency.toString())
                }
                socDataArray.add(socDataRow)
            })
        }
    }

    // 保存数据到Excel文件的方法
    private fun saveDataToExcel() {
        try {
            // 创建一个文件对象，指定文件名和路径
            val fileName = "ThermalMonitor_${startTime}_${endTime}.xls"
            val filePath = context?.getExternalFilesDir(null)?.absolutePath + "/ThermalMonitor"
            val file = File(filePath, fileName)

            // 创建一个工作簿对象
            val workbook = HSSFWorkbook()

            // 创建一个工作表对象
            val sheet = workbook.createSheet("Data")

            // 创建一个行对象，用于存储标题行
            val titleRow = sheet.createRow(0)

            // 定义一个变量，用于记录当前列的索引
            var columnIndex = 0

            // 如果电池数据数组不为空，将电池数据的标题添加到标题行中，并将电池数据添加到工作表中
            if (batteryDataArray.isNotEmpty()) {
                val batteryTitles = arrayOf("时间戳", "电量百分比", "充电状态", "实时电流", "电池温度", "电压", "供电来源")
                for (title in batteryTitles) {
                    titleRow.createCell(columnIndex).setCellValue(title)
                    columnIndex++
                }
                for (i in batteryDataArray.indices) {
                    val dataRow = sheet.createRow(i + 1)
                    for (j in batteryDataArray[i].indices) {
                        dataRow.createCell(j).setCellValue(batteryDataArray[i][j])
                    }
                }
            }

            // 如果温度数据数组不为空，将温度数据的标题添加到标题行中，并将温度数据添加到工作表中
            if (thermalDataArray.isNotEmpty()) {
                val thermalTitles = arrayOf("CPU温度", "GPU温度", "内存温度", "电池温度")
                for (title in thermalTitles) {
                    titleRow.createCell(columnIndex).setCellValue(title)
                    columnIndex++
                }
                for (i in thermalDataArray.indices) {
                    val dataRow = sheet.getRow(i + 1) ?: sheet.createRow(i + 1)
                    for (j in thermalDataArray[i].indices) {
                        dataRow.createCell(j + batteryDataArray[0].size).setCellValue(thermalDataArray[i][j])
                    }
                }
            }

            // 如果Soc数据数组不为空，将Soc数据的标题添加到标题行中，并将Soc数据添加到工作表中
            if (socDataArray.isNotEmpty()) {
                val socTitles = arrayOf("核心0频率", "核心1频率", "核心2频率", "核心3频率")
                for (title in socTitles) {
                    titleRow.createCell(columnIndex).setCellValue(title)
                    columnIndex++
                }
                for (i in socDataArray.indices) {
                    val dataRow = sheet.getRow(i + 1) ?: sheet.createRow(i + 1)
                    for (j in socDataArray[i].indices) {
                        dataRow.createCell(j + batteryDataArray[0].size + thermalDataArray[0].size).setCellValue(socDataArray[i][j])
                    }
                }
            }

            // 将工作簿写入文件中，并关闭工作簿
            workbook.write(file)
            workbook.close()

            // 提示用户保存成功，并显示文件路径
            Toast.makeText(context, "保存成功，文件路径为：$filePath/$fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            // 捕获异常，并提示用户保存失败
            e.printStackTrace()
            Toast.makeText(context, "保存失败，请重试或联系开发者", Toast.LENGTH_SHORT).show()
        }
    }
}
