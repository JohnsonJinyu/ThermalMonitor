package com.example.thermalmonitor.thermal

data class ThermalData(
    val zone: String,
    val type: String,
    val temp: String
)
